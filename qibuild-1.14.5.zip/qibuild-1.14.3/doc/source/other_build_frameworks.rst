.. _qibuild-compared-to-other-build-frameworks:

qiBuild compared to other build frameworks
==========================================

.. toctree::
    :maxdepth: 1

    other/cmake
    other/rosbuild
    other/qmake
    other/autotools


