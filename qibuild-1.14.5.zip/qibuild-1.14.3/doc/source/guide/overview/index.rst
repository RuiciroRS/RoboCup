qiBuild overview
================

.. toctree::

   creating_a_project
   configuring_a_project
   building_a_project
   testing_a_project
   packaging_a_project
   managing_deps
