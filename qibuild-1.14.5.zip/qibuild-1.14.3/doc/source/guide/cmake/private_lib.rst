.. _qibuild-private-lib:

Using private libraries
========================

Work in progress ...
