Using qiBuild CMake API
=======================

.. toctree::

   create_bin
   create_lib
   install
   test
   managing_config_files
   writing_a_config_cmake
   using_qi_stage

