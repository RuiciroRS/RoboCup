.. _qibuild-and-qmake:

qiBuild and qmake
=================

Introduction
------------

This section is targeted towards qmake users wanting to know more about
qiBuild


General comparison
------------------

Both frameworks try to be usable on as much as platforms as possible


What is in qmake and not in qiBuild
------------------------------------

* Nice integration is some IDEs (QtCreator mostly)


What is in qiBuild and not in qmake
-----------------------------------

* Nice Visual Studio support. You can use qmake with Visual Studio
  but it is a bit clumsy.


Using qiBuild with qmake projects
---------------------------------

Right now there are no plans to make the two work together.
