.. _qibuild-cfg-syntax:

Configuration files syntax
==========================



.. toctree::
   :maxdepth: 1

   qibuild_xml_syntax
   qiproject_xml_syntax
   qisrc_manifest_syntax
   toolchain_feed_syntax
