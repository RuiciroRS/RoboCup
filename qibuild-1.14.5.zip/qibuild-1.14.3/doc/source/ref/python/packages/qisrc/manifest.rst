qisrc.manifest -- Parsing manifest files
=========================================

.. automodule:: qisrc.manifest

.. seealso::

   * :ref:`qisrc-manifest-syntax`

qisrc.manifest.parse_manifest
------------------------------

.. autofunction:: parse_manifest
