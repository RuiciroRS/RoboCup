qisrc.git -- Git related tools
===============================

.. automodule:: qisrc.git


qisrc.git.Git
-------------

.. autoclass:: Git
   :members:
