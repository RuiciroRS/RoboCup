qibuild.archive -- Manage .tar.gz and .zip files
================================================

.. automodule:: qibuild.archive
   :members:

