qibuild.wizard -- Configuration wizards
=======================================

.. automodule:: qibuild.wizard

.. autofunction:: run_config_wizard
