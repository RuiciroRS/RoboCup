qibuild.envsetter -- controlling environment variables
======================================================

.. py:module:: qibuild.envsetter


qibuild.envsetter.EnvSetter
---------------------------

.. autoclass:: EnvSetter
   :members:
