qibuild.log -- Logging tools
============================

.. automodule:: qibuild.log


qibuild.log.ColorLogHandler
---------------------------

.. autoclass:: ColorLogHandler


Functions defined in this module
--------------------------------

.. autofunction:: configure_logging

.. autofunction:: get_current_log_level
