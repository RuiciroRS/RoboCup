qibuild.cmake - CMake tools
===========================

.. automodule:: qibuild.cmake
   :members:
