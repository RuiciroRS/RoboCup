qibuild.sh -- Common filesystem operations
==========================================

.. automodule:: qibuild.sh
   :members:
