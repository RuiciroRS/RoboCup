qibuild.ctest -- Implementation of CTest in Python
==================================================

.. automodule:: qibuild.ctest


qibuild.ctest.run_tests
-----------------------

.. autofunction:: qibuild.ctest.run_tests


qibuild.ctest.run_test
----------------------

.. autofunction:: qibuild.ctest.run_test
