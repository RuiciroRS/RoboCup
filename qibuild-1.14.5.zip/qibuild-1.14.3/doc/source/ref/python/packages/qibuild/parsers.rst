qibuild.parsers -- Parsers for qibuild actions
==============================================

.. py:module:: qibuild.parsers



Functions defined in this module
--------------------------------

.. autofunction:: toc_parser

.. autofunction:: build_parser

.. autofunction:: project_parser
