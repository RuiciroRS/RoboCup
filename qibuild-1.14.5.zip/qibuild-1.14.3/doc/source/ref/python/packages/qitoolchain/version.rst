qitoolchain.version -- Managing packages versions
==================================================

.. automodule:: qitoolchain.version

qitoolchain.version.compare
---------------------------

.. autofunction:: compare
