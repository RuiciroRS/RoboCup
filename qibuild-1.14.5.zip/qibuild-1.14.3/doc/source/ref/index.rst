.. _qibuild-ref:

qiBuild reference documentation
===============================


.. toctree::
   :maxdepth: 1

   man/index
   cmake/api
   cfg/index
   python/index

