## Copyright (c) 2012 Aldebaran Robotics. All rights reserved.
## Use of this source code is governed by a BSD-style license that can be
## found in the COPYING file.
"""actions.qitoolchain

This package contains the qitoolchain actions.

qitoolchain actions handle toolchains, which are
just a collection of binary packages

"""

