C++
===



.. code-block:: rst

    .. This does not work

    qibuild ref does not work like this: :ref:`qibuild:qibuild-aldeb`

But this does:

qibuild ref works like this: `<Using qiBuild with Aldebaran Packages <../qibuild/qibuild_aldeb.html>`_


.. toctree::
    :hidden:

    tutos/cpp.rst
