C++ Tutorials
=============


.. code-block:: rst

    .. This does not work

    qibuild ref does works from here too :ref:`qibuild:qibuild-aldeb`

But this does:

qibuild ref works like this: `<Using qiBuild with Aldebaran Packages <../../qibuild/qibuild_aldeb.html>`_
