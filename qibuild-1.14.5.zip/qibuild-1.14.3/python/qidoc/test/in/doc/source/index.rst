.. Aldebaran Developper Documentation documentation master file, created by
   sphinx-quickstart on Thu Aug  4 14:15:19 2011.

Aldebaran Documentation
=======================

.. toctree::
   :hidden:

   contents
   dev/cpp

