int main()
{
  proxy = ALProxy();
  return 0;
}
