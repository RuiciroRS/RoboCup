/** @file
 *  @brief
 */

/**
 * \class ALProxy alproxy.h "alcommon/alproxy.h"
 *
 * Yeah ALProxy
 */
class ALProxy {

}
