/** @file
 *  @brief
 */

/**
 * \class ALImage alimage.h "alimage/alimage.h"
 *
 * Yeah ALImage
 * \example vision.cpp
 */
class ALImage {

}
