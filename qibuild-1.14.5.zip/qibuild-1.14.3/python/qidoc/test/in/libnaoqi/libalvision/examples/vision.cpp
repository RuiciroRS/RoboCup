int main()
{
  proxy = ALProxy();
  image = ALImage();
  return 0;
}
