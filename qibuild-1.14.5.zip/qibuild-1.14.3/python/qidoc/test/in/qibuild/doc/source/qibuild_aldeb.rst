.. _qibuild-aldeb:

Using qiBuild with Aldebaran packages
=====================================
