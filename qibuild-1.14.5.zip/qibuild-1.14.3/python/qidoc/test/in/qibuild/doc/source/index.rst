qiBuild documentation
=====================


SDK_DIRS
--------

See also :libqi:`qi::path::findData`


.. toctree::
    :hidden:

    qibuild_aldeb

.. toctree::

    samples/fooproject/index
    samples/api/submodule/index

Tutorials
---------

* :ref:`qibuild-aldeb`
