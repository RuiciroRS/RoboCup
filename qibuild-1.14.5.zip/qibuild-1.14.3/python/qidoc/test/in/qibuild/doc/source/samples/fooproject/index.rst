FooProject
==========

An example

.. literalinclude:: CMakeLists.txt
    :language: cmake


Download the fooproject here: :download:`fooproject.zip <../fooproject.zip>`
