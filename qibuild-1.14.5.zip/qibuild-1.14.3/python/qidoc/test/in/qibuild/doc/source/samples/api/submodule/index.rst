Submodule API
=============

Example

.. literalinclude:: CMakeLists.txt
    :language: cmake

And you can download it here :download:`submodule.zip <../submodule.zip>`
