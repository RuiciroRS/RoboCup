#include "world.hpp"
#include <iostream>
int main()
{
  std::cout << "The answer is: " << world_answer() << std::endl;
  return 0;
}
