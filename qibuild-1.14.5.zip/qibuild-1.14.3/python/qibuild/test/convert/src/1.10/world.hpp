#ifndef _WORLD_HPP
#define _WORLD_HPP
int world_answer();

#endif // _WORLD_HPP
