int world_answer()
{
  return 42;
}
