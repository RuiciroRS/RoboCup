#include <cc.h>
int c() { return 0; }
