#include <cc.h>
#include <d.h>

int main()
{
  c();
  d();
  return 0;
}
