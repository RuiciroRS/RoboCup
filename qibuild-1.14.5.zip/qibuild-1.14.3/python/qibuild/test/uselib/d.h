#ifndef _D_H
#define _D_H

int d();

#endif
