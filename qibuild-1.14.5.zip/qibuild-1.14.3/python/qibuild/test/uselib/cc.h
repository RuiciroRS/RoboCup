#ifndef _C_H
#define _C_H

int c();
#endif
