#include <a.h>
#include <b.h>

int d()
{
  return a() + b();
}
