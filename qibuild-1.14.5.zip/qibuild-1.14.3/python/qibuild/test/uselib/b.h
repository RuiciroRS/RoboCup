#ifndef _B_H
#define _B_H

int b();
#endif
