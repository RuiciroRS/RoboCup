#include <a.h>
int a() { return 0; }
