#ifndef _A_H
#define _A_H

int a();
#endif
