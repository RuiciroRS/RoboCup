#include <b.h>
int b() { return 0; }
