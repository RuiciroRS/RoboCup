enum E { a, b, c };

void func ( E e )
{
   switch(e)
   {
      case a:
        break;
      case b:
        break;
   }
}


int main()
{
}
