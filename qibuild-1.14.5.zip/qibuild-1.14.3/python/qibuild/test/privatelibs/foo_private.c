#include "foo_private.h"

int _private_foo()
{
  return 42;
}
