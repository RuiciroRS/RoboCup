#ifndef _FOO_PRIVATE_H
#define _FOO_PRIVATE_H

int _private_foo();

#endif
