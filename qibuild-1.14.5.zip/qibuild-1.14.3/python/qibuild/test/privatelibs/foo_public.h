#ifndef _FOO_PUBLIC_H
#define _FOO_PUBLIC_H

int foo();

#endif
