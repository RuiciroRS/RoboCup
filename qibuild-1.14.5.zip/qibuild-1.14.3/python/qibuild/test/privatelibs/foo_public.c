#include "foo_private.h"

int foo()
{
  return _private_foo();
}
