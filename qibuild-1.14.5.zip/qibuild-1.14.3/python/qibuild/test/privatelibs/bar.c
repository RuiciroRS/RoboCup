#include "foo_public.h"

int  main(int argc, char* argv[])
{
  foo();
  return 0;
}
